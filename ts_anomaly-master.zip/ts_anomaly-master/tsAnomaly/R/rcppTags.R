#' @useDynLib tsAnomaly
#' @importFrom Rcpp sourceCpp
NULL